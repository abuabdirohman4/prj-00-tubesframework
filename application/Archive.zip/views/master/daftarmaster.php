    <style> 
    
    button{
        font-size: 30px;

    }
    </style>
    <p>
    <br><center><button><a href="../index.php/bahan">BAHAN</a></button> &nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <button><a href="../index.php/coa">COA</a></button>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <button><a href="../index.php/kategori">KATEGORI</a></button><br><br>
    <button><a href="../index.php/minuman">MINUMAN</a></button>  &nbsp;&nbsp;&nbsp;
    <button><a href="../index.php/pegawai">PEGAWAI</a></button><br><br>
    <button><a href="../index.php/vendor">VENDOR</a></button></center></p>   &nbsp;&nbsp;&nbsp;
    <br><br><br><br><br><br><br><br><br><br><br><br>